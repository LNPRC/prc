clearvars -except strCur model io dp pav;
clc;

Lg=1.0e-4;
Rg=5e-3;
C=150e-6;
Rc=0.1;
Lf=2e-4;Rf=0.0;
td=2e-5;
w=50*2*pi;
kpi=1;kii=10;
kpv=1;kiv=10;
kpq=.1;kiq=5;
Tn=0.01;Td=0.1;
% Tp=0.001;Gp=0.35;
Dp=3;J=0.001;
Gp=1/Dp;
Tp=J/Dp;
Zbase=0.0952;
Gf=4*0.25;Gfv=2*0.25;Kdc=1*1*w*Lf;Kdv=1*1*w*C;
Cdc=20e-3;Rdc=1e3;
Sb=5e6;Vdc=1.5e3;
Idc=Sb/Vdc;
Ten=35;
%% type ii 25us
% gv=1;%voltage loop gain modification
% nw=12;%number of fundamental frequency
% tm=56.5;
% Ts=2.5e-5;
%% type ii 50us
gv=.85;%voltage loop gain modification
nw=5;%number of fundamental frequency
tm=72.5;
Ts=5e-5;
%% others

kppll=100;
Ub=0.69e3*sqrt(2/3);
Ib=5e6/0.69e3/sqrt(3/2);
Km=0.5;

kpdc=1.5;kidc=15;
fp=-53;fpm=Ub*0.00;
Kc=1;%0 for controller frame while 1 for grid frame

Acd=[0,conv([Lg, Rg],[C*Rc,1])]+conv([Lf,Rf],[Lg*C,Rg*C+C*Rc,1]);
Acn=[Lg*C,C*Rg+C*Rc,1];
Bgd=conv([0,conv([Lf,Rf],[C*Rc,1])]+conv([Lg,Rg],[Lf*C,C*Rf+C*Rc,1]),[C*Lf,C*(Rc+Rf),1]);
Bgn=conv([Lf*C,C*Rf+C*Rc,1],[C*Rc,1]);
% load initial_state;

Ud0=563.38;Uq0=0;U0=563.38;%%PCC 
Icd0=5902.675;Icq0=18.535;
Ucd0=563.3;Ucq0=372.65;%%converter side voltage
Igd0=5902.64189;
Ugd0=532.4;
Ugq0=-184.225;
Igq0=-70;
Mdc=0.7551;
Mqc=0.4942;


Aedc=-1/Cdc/Rdc;
Bedc=[1/Cdc,-1/Cdc];
Cedc=1/Vdc;Dedc=[0,0];

Ae=[-Rf/Lf,w,-1/Lf,0,0,0;
        -w,-Rf/Lf,0,-1/Lf,0,0;
        1/C-Rc*Rf/Lf,0,-Rc*(1/Lg+1/Lf),w,-1/C+Rc*Rg/Lg,0;
        0,1/C-Rc*Rf/Lf,-w,-Rc*(1/Lg+1/Lf),0,-1/C+Rc*Rg/Lg;
        0,0,1/Lg,0,-Rg/Lg,w;
        0,0,0,1/Lg,-w,-Rg/Lg];
Be=[1/Lf,0,0,0,Icq0;
    0,1/Lf,0,0,-Icd0;
    Rc/Lf,0,Rc/Lg,0,Igq0;
    0,Rc/Lf,0,Rc/Lg,-Igd0;
    0,0,-1/Lg,0,Uq0;
    0,0,0,-1/Lg,-Ud0];
Ce=[1,0,0,0,0,0;
        0,1,0,0,0,0;
        0,0,1,0,0,0;
        0,0,0,1,0,0;
        0,0,Ud0/U0,Uq0/U0,0,0;
        1.5*Ud0,1.5*Uq0,1.5*Icd0,1.5*Icq0,0,0;
        1.5*Uq0,-1.5*Ud0,-1.5*Icq0,1.5*Icd0,0,0;
        0,0,0,0,1,0;
        0,0,0,0,0,1];
De=zeros(9,5);

Ac=[0,0;0,0];
Bc=[1,0,-1,0,0,0;
        0,1,0,-1,0,0];
Cc=[kii,0;0,kii];
Dc=[kpi,0,-kpi,-Kdc,Gf,0;
        0,kpi,Kdc,-kpi,0,Gf];

Av=[0,0;0,0];
Bv=[1,0,-1,0,0,0;
        0,1,0,-1,0,0];
Cv=[kiv,0;0,kiv];
Dv=[kpv,0,-kpv,-Kdv,Gfv,0;
        0,kpv,Kdv,-kpv,0,Gfv];


% As=[0,0,0,0;0,0,1,0;0,0,-1/Tp,w*Gp/Tp;0,0,0,0];
% Bs=[0,0,0,0,kppll;0,0,0,0,0;-w*Gp*kpdc/Tp,w*Gp*kpdc/Tp,w*Gp/Tp,-w*Gp/Tp,0;-kidc,kidc,0,0,0];
% Cs=[1,1,0,0];
% Ds=[0,0,0,0,0];

As=[0,1,0;0,-1/Tp,w*Gp/Tp*kidc;0,0,0];
Bs=[0,0,0,0,kppll;-w*Gp*kpdc/Tp,w*Gp*kpdc/Tp,w*Gp/Tp,-w*Gp/Tp,0;-1,1,0,0,0];
Cs=[1,0,0];
Ds=[0,0,0,0,0];

%%reactive power
Aq=0;
Bq=[1,-1];
Cq=[kiq;0];
Dq=[kpq,-kpq;0,0];

Inic=[0,0];
Iniv=[0,0];
Iniq=0;
Inie=0*[5916.64189,29.7777,563.38,0,5913.172,-58.58];
Inis=0*[0,0,0];
% Inie=0*Inie;